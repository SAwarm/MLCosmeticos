<?php

require("./vendor/autoload.php");

use \App\Pix\Payload;
use Mpdf\QrCode\QrCode;
use Mpdf\QrCode\Output;

$chave = "07359744970";
$preco = $_GET['preco'];
//print_r($preco);

$obPayload = (new Payload)->setPixKey($chave) // key pix
                          ->setDescription('payment') // description of the pix
                          ->setMerchantName('') // name people
                          ->setMerchantCity("Sombrio") // city 
                          ->setAmount($preco) // price of pix
                          ->setTxid('TestId'); // id pix

$payloadQrCode = $obPayload->getPayload();

$objectCode = new QrCode($payloadQrCode);

$image = (new Output\Png)->output($objectCode, 800);

//header('Content-Type: image/png');
echo '<img style = "width: 300px; height 400px; margin-left: 80px;" src="data:image/png;base64,'.base64_encode($image).'" />';