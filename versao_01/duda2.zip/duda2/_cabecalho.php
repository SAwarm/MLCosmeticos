<nav>
	<div id="anuncio"></div>
	<div id="head">
		<a href="/"><img src="logo.png" alt="logo" height="100px" width="100%"></a>
		<input class="pesquisa" placeholder="Busco por"></input>
		<span class="links">
			<a href="#">Ajuda</a>
			<a href="#">Contatos</a>
			<a href="#">Bananas</a>
			<a href="#">Carrinho</a>
		</span>
	</div>
	<div id="head-links">
		<ul>
			<li>
				<a href="/rosto.php">rosto</a>
				<div class="menu">
					<a href="/rosto/base.php">Base</a>
					<a href="/rosto/po.php">Pó</a>
					<a href="/rosto/primer.php">Primer facial</a>
					<a href="/rosto/blush.php">Blush</a>
					<a href="/rosto/corretivo.php">Corretivo e contorno</a>
					<a href="/rosto/bronzer.php">Bronzer e iluminador</a>
					<a href="/rosto/paletas.php">Paletas</a>
					<a href="/rosto/kit.php">Kit combo base e corretivo feels</a>
				</div>	
			</li>
			<li>
				<a href="/labios.php">lábios</a>
				<div class="menu">
					<a href="/labios/matte.php">Batom matte</a>
					<a href="/labios/duo.php">Batom duo</a>
					<a href="/labios/liquido.php">Batom líquido</a>
					<a href="/labios/gloss.php">Gloss labial</a>
					<a href="/labios/liquido_metalizado.php">Batom líquido metalizado</a>
					<a href="/labios/lit_tint.php">Lip tint</a>
					<a href="/labios/lip_oil.php">Lip oil</a>
					<a href="/labios/kisses.php">Batom líquido kisses glitter</a>
					<a href="/labios/gel_tint.php">Gel tint</a>
					<a href="/labios/glaze.php">Lip glaze feels</a>
					<a href="/labios/top_coat.php">Top coat shine</a>
					<a href="/labios/esfoliante.php">Esfoliante labial</a>
					<a href="/labios/make_glossy.php">Efeito make glossy + esfoliante</a>
					<a href="/labios/balm.php">Balm</a>
					<a href="/labios/cremoso.php">Batom cremoso</a>
				</div>
			</li>

			<li>
				<a href="olhos.php">olhos</a>
				<div class="menu">
					<a href="/olhos/mascara.php">Máscara para cílios</a>
					<a href="/olhos/delineador.php">Delineador</a>
					<a href="/olhos/sombras.php">Sombras</a>
					<a href="/olhos/lapis.php">Lápis para olhos</a>
					<a href="/olhos/primer.php">Primer para olhos</a>
					<a href="/olhos/glitter.php">Glitter shine</a>
					<a href="/olhos/pigmento.php">Pigmento shine</a>
				</div>
			</li>
			<li>
				<a href="#">sobrancelhas</a>
			</li>
			<li>
				<a href="facial.php">linha facial</a>
				<div class="menu">
					<a href="/facial/limpeza.php">Limpeza</a>
					<a href="/facial/demaquilante.php">Demaquilante e tônico</a>
					<a href="/facial/tratamento.php">Tratamento</a>
					<a href="/facial/sabonetes.php">Sabonetes</a>
					<a href="/facial/hidratacao.php">Hidratação</a>
					<a href="/facial/serum.php">Sérum</a>
					<a href="/facial/fixadores.php">Fixadores</a>
					<a href="/facial/tratamento.php">Kits para tratamento</a>
					<a href="/facial/protecao.php">Linha ruby skin proteção urbana</a>
					<a href="/facial/combo_oleosidade.php">Combo básico oleosidade</a>
					<a href="/facial/combo_hidratacao.php">Combo básico hidratação</a>
				</div>
			</li>
			<li>
				<a href="argila.php">argila rosa</a>
				<div class="menu">
					<a href="/argila/facial.php">Argila rosa facial</a>
					<a href="/argila/capilar.php">Argila rosa capilar</a>
				</div>
			</li>
			<li>
				<a href="kits.php">kits e acessórios</a>
				<div class="menu">
					<a href="/kits/presentes.php">Kits e presentes</a>
					<a href="/kits/acessorios.php">Acessórios e embalagens</a>
					<a href="/kits/brindes.php">Brindes</a>
					<a href="/kits/combo_base.php">Kit combo base e corretivo feels</a>
					<a href="/kits/mães">kits dia das mães</a>
				</div>
			</li>
			<li>
				<a href="colecoes.php">coleções</a>
				<div class="menu">
					<a href="/colecoes/feels.php">Linha feels</a>
					<a href="/colecoes/shine.php">Linha shine</a>
					<a href="/colecoes/ice.php">Linha ice</a>
					<a href="/colecoes/care.php">Linha care</a>
					<a href="/colecoes/skin.php">Linha ruby skin</a>
				</div>
			</li>
			<li>
				<a href="lancamentos.php">lançamentos</a>
				<div class="menu">
					<a href="/colecoes/shine.php">Linha shine</a>
					<a href="/colecoes/feels.php">Linha feels</a>
					<a href="/olhos/sombras.php">Paleta de sombras</a>
					<a href="/colecoes/care.php">Linha care</a>
					<a href="/facial/protecao.php">Linha ruby skin proteção urbana</a>
					<a href="/lancamentos/gel.php">Gel volumizador de sobrancelha</a>
				</div>
			</li>
		</ul>
	</div>
</nav>