<div id="contato">
	<span>bota teu email dos guri ai parcero</span>
	<form>
		<input placeholder="seu nome"/>
		<input placeholder="seu e-mail"/>
		<button type="submit">castrar</button>
	</form>
</div>
<div id="rodape">
	<p class="redes" style="font: 22pt 'Arial'">Segue os cupinxa ai</p>
	<div class="listas">
		<ul>
			<li>Destaque</li>
			<li>tiriri</li>
		</ul>
		<ul>
			<li>Precisa de ajuda?</li>
			<li>tiriri</li>
		</ul>
		<ul>
			<li>Apoio</li>
			<li>tiriri</li>
		</ul>
	</div>
	<p id="rodape-inferior">Todas as lhamas reservadas</p>
</div>