<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    
    <link rel="stylesheet" href="res/css/style.css"/>
    <link rel="stylesheet" href="res/css/style-carrinho.css"/>
	<script src="/res/js/lib/jquery-1.12.4.min.js" crossorigin="anonymous"></script>
	<script src="res/scripts.js"></script>
    <title>Carrinho</title>
</head>
<body>
    <header>
		<?php include '_cabecalho.php';?>
	</header>
</body>
</html>